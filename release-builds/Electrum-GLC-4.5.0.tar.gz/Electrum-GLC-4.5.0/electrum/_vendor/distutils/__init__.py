"""(part of) distutils, taken from the cpython standard library

at commit https://github.com/python/cpython/tree/9d38120e335357a3b294277fd5eff0a10e46e043/Lib/distutils
"""
